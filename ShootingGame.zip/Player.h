#pragma once
#include "Bullet.h"
#include "Base.h"
class Player :
	public Base
{
public:
	Player();
	virtual ~Player();

	bool isinvincible = false;

	void ShootBullet();

	void Move() override;
	void Clip();
	void Update() override;
};
