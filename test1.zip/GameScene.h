#pragma once
#include "Scene.h"
#include "Sprite.h"
#include "Camera.h"
class GameScene :
	public Scene
{
public:
	Sprite* sprite = nullptr;
	Sprite* sprite2 = nullptr;
	void Init() override;
	void Update() override;
	void Exit() override;
};
