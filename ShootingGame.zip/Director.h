#pragma once
#include "Scene.h"
#include "Singleton.h"
class Director :
	public Singleton<Director>
{
private:
	Scene* currentScene;
public:
	LPD3DXSPRITE sprite;

	int mouse = 0;
	int score = 0;
	bool isgameend = false;
	bool lookrank = false;
	vector<Rank> ranking;

	bool OnMouseDown()
	{
		if (mouse == 1) return true;
		return false;
	};
	bool OnMouse()
	{
		if (mouse == 2) return true;
		return false;
	};
	bool OnMouseUp()
	{
		if (mouse == 3) return true;
		return false;
	};

	static bool Comp(Rank a, Rank b)
	{
		return a.score > b.score;
	};

	void Init();
	void ChangeScene(Scene* _scene);
	void UpdateScene();
};
