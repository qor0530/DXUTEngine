#pragma once
#include "Bullet.h"
#include "Base.h"
class Enemy :
	public Base
{
public:
	EnemyType etype;

	Enemy();
#pragma region ENEMY1
	void Enemy1Move();
	void Enemy1Attack();
#pragma endregion
#pragma region ENEMY2
	Vec2* playerpos;
	Vec2 direction;
	void Enemy2Move();
	void Enemy2Attack();
#pragma endregion

	void Move() override;
	void Update() override;
};
