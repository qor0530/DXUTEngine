#pragma once
#include "Sprite.h"
#include "Font.h"
#include "rankScene.h"
#include "Scene.h"
class menuScene :
	public Scene
{
public:
	Sprite* buttons[3];
	Font* font;

	void Init() override;
	void Update() override;
	void Exit() override;
};
