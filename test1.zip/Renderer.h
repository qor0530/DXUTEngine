#pragma once
#include "Node.h"
#include "Singleton.h"
class Renderer :
	public Singleton<Renderer>
{
private:
	list<Node*> rendertargets;
	static bool Comp(Node* a, Node* b);
public:
	void AddRenderTarget(Node* node);
	void RemoveRenderTarget(Node* node);
	void Sort();
	void Render();
	void Clear() { rendertargets.clear(); };
};
