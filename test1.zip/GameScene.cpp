#include "DXUT.h"
#include "GameScene.h"

void GameScene::Init()
{
	cout << "GameScene Init" << endl;
	sprite = new Sprite();
	sprite->SetTexture(L"myshooting.jpg");
	sprite->position = { ScreenW / 2, ScreenH / 2 };
	sprite2 = new Sprite();
	sprite2->SetTexture(L"myshooting.jpg");
	sprite2->color = Color(1, 0, 0, 1);
	Camera::GetInstance()->CameraInit();
}

void GameScene::Update()
{
	RECT r;
	if (IntersectRect(&r, &sprite->GetRect(), &sprite2->GetRect()))
	{
		cout << "�浹" << endl;
	}
	else
		cout << "�浹 ����" << endl;

	if (DXUTIsKeyDown('W'))
	{
		sprite->position.y -= 300.1f * DELTATIME;
	}
	if (DXUTIsKeyDown('A'))
	{
		sprite->position.x -= 300.1f * DELTATIME;
	}
	if (DXUTIsKeyDown('S'))
	{
		sprite->position.y += 300.1f * DELTATIME;
	}
	if (DXUTIsKeyDown('D'))
	{
		sprite->position.x += 300.1f * DELTATIME;
	}
	Camera::GetInstance()->CameraUpdate();
}

void GameScene::Exit()
{
	cout << "GameScene Exit" << endl;
	SAFE_DELETE(sprite);
	SAFE_DELETE(sprite2);
}