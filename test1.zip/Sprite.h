#pragma once
#include "Texture.h"
#include "Node.h"
#include "Director.h"
#include "Renderer.h"
class Sprite :
	public Node
{
public:
	Sprite() {};
	virtual ~Sprite();

	Texture* texture = nullptr;

	void SetTexture(wstring path);
	RECT GetRect();

	float GetDistance(Vec2 obj);
	float Look(Vec2 obj);

	void Update() override {};
	void Draw() override;
};
