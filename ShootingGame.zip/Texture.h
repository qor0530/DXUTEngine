#pragma once
#include "Singleton.h"
class Texture
{
public:
	D3DXIMAGE_INFO info;
	LPDIRECT3DTEXTURE9 texture;
	wstring tag;
};

class TextureManager :
	public Singleton<TextureManager>
{
private:
	list<Texture*> texturelist;
public:
	Texture* LoadTexture(wstring path);
};