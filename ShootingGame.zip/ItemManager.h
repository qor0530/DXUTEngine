#pragma once
#include "Player.h"
#include "Singleton.h"
class ItemManager :
	public Singleton<ItemManager>
{
public:
};