#include "DXUT.h"
#include "Singleton.h"