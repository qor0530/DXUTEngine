#include "DXUT.h"
#include "Node.h"

D3DXMATRIX Node::GetMatrix()
{
	D3DXMATRIX m;
	D3DXMatrixTransformation2D(&m, nullptr, 0, &scale, nullptr, rotation, &position);
	return m;
}