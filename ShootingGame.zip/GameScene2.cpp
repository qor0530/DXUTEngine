#include "DXUT.h"
#include "menuScene.h"
#include "GameScene.h"
#include "GameScene2.h"

void GameScene2::Init()
{
	cout << "����" << endl;
	p = new Player();
	BulletManager::GetInstance()->CreateBullet();
	EnemyManager::GetInstance()->CreateEnemy();
	EffectManager::GetInstance()->CreateEffect();

	Camera::GetInstance()->CameraInit();
	Sound::GetInstance()->LoadSound(L"Res/Bgm.wav", L"BGM");
	Sound::GetInstance()->PlaySFX(L"BGM", true);

	for (int i = 0; i < 2; ++i)
	{
		back[i] = new Sprite();
		back[i]->SetTexture(L"background.png");
		back[i]->layer = -30;
		Renderer::GetInstance()->Sort();
	}
	back[0]->position = { ScreenW / 2, ScreenH / 2 };
	back[1]->position = { ScreenW / 2, -(ScreenH / 2) };

	for (int i = 0; i < 9; ++i)
	{
		ui[i] = new Sprite();
		ui[i]->scale = { 2,2 };
		ui[i]->layer = 10;
		ui[i]->SetTexture(L"player1.png");

		ui[i]->position = { 55 + ((float)i * 60), 45 };
	}
	for (int i = 0; i < 9; ++i)
		ui[i]->isactive = false;
	for (int i = 0; i < p->HP; ++i)
		ui[i]->isactive = true;
	b = new Boss();
	b->position = { ScreenW / 2, -100 };

	scorefont = new Font();
	scorefont->Createfont(2, 2, L"Arial");
	scorefont->position = { ScreenW / 2 + 400,10 };

	levelfont = new Font();
	levelfont->Createfont(2, 2, L"Arial");
	levelfont->position = { 180,150 };

	hpfont = new Font();
	hpfont->Createfont(2, 2, L"Arial");
	hpfont->position = { 180,300 };

	expfont = new Font();
	expfont->Createfont(2, 2, L"Arial");
	expfont->position = { 180,450 };
}

void GameScene2::Update()
{
	for (int i = 0; i < 9; ++i)
		ui[i]->isactive = false;
	for (int i = 0; i < p->HP; ++i)
		ui[i]->isactive = true;

	bossspawntime += DELTATIME;
	if (bossspawntime > 3)
	{
		if (b->position.y < 100)
			b->position.y += 30 * DELTATIME;
		else
			b->startpattern = true;
	}

	dt += DELTATIME;
	if (dt > 3.f)
	{
		if (num == 0)
		{
			EnemyManager::GetInstance()->SpawnEnemy({ ScreenW / 2,0 }, E1, p);
			num = 1;
		}
		else
		{
			EnemyManager::GetInstance()->SpawnEnemy({ ScreenW / 2,0 }, E2, p);
			num = 0;
		}
		dt = 0;
	}

	Camera::GetInstance()->CameraUpdate();

	for (int i = 0; i < 2; ++i)
	{
		back[i]->position.y += 200.f * DELTATIME;

		if (back[i]->position.y > (ScreenH + ScreenH / 2))
			back[i]->position.y = -(ScreenH / 2);
	}

	string scoreNum = to_string(Director::GetInstance()->score);
	string Sresult = "Score : " + scoreNum;
	scorefont->SetFont((char*)Sresult.c_str());

	string levelNum = to_string(p->level);
	string Lresult = "Level : " + levelNum;
	levelfont->SetFont((char*)Lresult.c_str());

	string hpNum = to_string(p->HP);
	string maxhpNum = to_string(p->maxhp);
	string Hresult = "Hp : " + hpNum + " / " + maxhpNum;
	hpfont->SetFont((char*)Hresult.c_str());

	string expNum = to_string(p->exp);
	string maxexpNum = to_string(p->maxexp);
	string Eresult = "Exp : " + expNum + " / " + maxexpNum;
	expfont->SetFont((char*)Eresult.c_str());

	if (DXUTWasKeyPressed('U'))
		Director::GetInstance()->score += 100;

	if (DXUTWasKeyPressed('P'))
	{
		Director::GetInstance()->ChangeScene(new menuScene);
		return;
	}

	if (DXUTWasKeyPressed(VK_F1))
	{
		Director::GetInstance()->score += 100;
	}

	if (p->HP <= 0)
	{
		Director::GetInstance()->isgameend = true;
		Director::GetInstance()->ChangeScene(new rankScene);
		return;
	}
}

void GameScene2::Exit()
{
	cout << "������" << endl;
	for (int i = 0; i < 5; ++i)
		delete	ui[i];
	for (int i = 0; i < 2; ++i)
		delete	back[i];
	delete p;
	delete b;
	delete scorefont;

	BulletManager::GetInstance()->DeleteBullet();
	EnemyManager::GetInstance()->DeleteEnemy();
	EffectManager::GetInstance()->DeleteEffect();
	Sound::GetInstance()->StopSFX(L"BGM");
}