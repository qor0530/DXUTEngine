#pragma once
class Node
{
public:
	Node() {};
	virtual ~Node() {};

	Vec2 position = { 0,0 };
	Vec2 scale = { 1,1 };
	Vec2 pivot = { 0.5f, 0.5f };
	int layer = 0;
	float rotation = 0;
	bool isactive = true;
	bool isui = false;
	Color color = Color(1, 1, 1, 1);
	RECT imageRect;

	D3DXMATRIX GetMatrix();

	virtual void Update() {};
	virtual void Draw() {};
};
