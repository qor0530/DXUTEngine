#pragma once
#include "Sprite.h"
class Base :
	public Sprite
{
public:
	Base();
	virtual ~Base();

	ObjectType type;
	Sprite* objecttexture;

	int HP = 5;
	float movespeed = 15.f;
	float attackspeed = 0.5f;
	float deltatime = 0;
	float invincibletime = -1.f;
	int damage = 1;
	bool isPlayer = false;

	void GetDamage(int damage);
	void CheckCollision();
	virtual void Activefalse() {};
	virtual void Move() {};
	void Update() override;
};
