#include "DXUT.h"
#include "Player.h"

Player::Player()
{
	HP = 5;
	movespeed = 200.f;
	position = { ScreenW / 2,ScreenH / 2 + 150 };
	scale = { 0.7f,0.7f };
	layer = 31;
	objecttexture->SetTexture(L"player1.png");
	color.a = 0;
	SetTexture(L"collisionbox.png");
	isPlayer = true;
	isStraight = false;
	straightTime = 0.5;
	radialTime = 1;
	fireBetTime = 0;
	ShieldTime = 10;
	ScoolTime = 0;
	type = PLAYER;
	Sound::GetInstance()->LoadSound(L"Res/ShootingSound.wav", L"ShootingSound");
}

Player::~Player()
{
}

void Player::ShootBullet()
{
	fireBetTime -= DXUTGetElapsedTime();
	if (GetAsyncKeyState(VK_SPACE))
	{
		if (isStraight)
		{
			if (fireBetTime <= 0)
			{
				Sound::GetInstance()->PlaySFX(L"ShootingSound", false);
				fireBetTime = straightTime;
				BulletManager::GetInstance()->ShootBullet(position, PLAYER, { 0 ,0 });
			}
		}
		else
		{
			if (fireBetTime <= 0)
			{
				Sound::GetInstance()->PlaySFX(L"ShootingSound", false);
				fireBetTime = radialTime;
				for (int i = 0; i < 5; i++)
				{
					BulletManager::GetInstance()->ShootBullet(position, PLAYER, { static_cast<float>(i - 2) , -2 });
				}
			}
		}
	}
}

void Player::Toggle()
{
	static bool isPush = false;

	if (GetAsyncKeyState('Z') && !isPush)
	{
		isStraight = !isStraight;
		isPush = true;
	}
	if (!GetAsyncKeyState('Z'))
	{
		isPush = false;
	}
}

void Player::Move()
{
	if (DXUTIsKeyDown('W'))
		position.y -= movespeed * DELTATIME;
	if (DXUTIsKeyDown('A'))
		position.x -= movespeed * DELTATIME;
	if (DXUTIsKeyDown('S'))
		position.y += movespeed * DELTATIME;
	if (DXUTIsKeyDown('D'))
		position.x += movespeed * DELTATIME;
}

void Player::Clip()
{
	if (position.x > ScreenW - texture->info.Width / 2 * scale.x)
		position.x = ScreenW - texture->info.Width / 2 * scale.x;
	if (position.x < texture->info.Width / 2 * scale.x)
		position.x = texture->info.Width / 2 * scale.x;
	if (position.y > ScreenH - texture->info.Height / 2 * scale.y)
		position.y = ScreenH - texture->info.Height / 2 * scale.y;
	if (position.y < texture->info.Height / 2 * scale.y)
		position.y = texture->info.Height / 2 * scale.y;
}

void Player::Leveling()
{
	if (exp >= maxexp || levelUp)
	{
		if (level < 5)
		{
			movespeed += 50;
			straightTime -= 0.08;
			radialTime -= 0.16;
			level++;
			exp = 0;
			Director::GetInstance()->exp = 0;
			maxexp += 5;
			maxhp += maxhp / 5;
			cout << maxhp << endl;
			HP = maxhp;
		}
		levelUp = false;
	}
}

void Player::Update()
{
	exp = Director::GetInstance()->exp;
	if (DXUTWasKeyPressed(VK_F1))
		isinvincible = !isinvincible;

	if (DXUTWasKeyPressed(VK_F2))
	{
		levelUp = true;
		Leveling();
	}

	if (DXUTWasKeyPressed(VK_F3))
		isinvincible = !isinvincible;

	if (DXUTWasKeyPressed(VK_F4))
		isinvincible = !isinvincible;

	if (DXUTWasKeyPressed(VK_F5))
		isinvincible = !isinvincible;

	if (GetAsyncKeyState('X'))
		Shield();
	if (isinvincible)
		HP = maxhp;
	ShootBullet();
	Base::Update();
	Clip();
	Toggle();
	Leveling();
}

void Player::Shield()
{
	ScoolTime -= DXUTGetElapsedTime();
	if (ScoolTime <= 0)
	{
		ScoolTime = ShieldTime;
		invincibletime = 3;
		cout << "����" << endl;
	}
}