#include "DXUT.h"
#include "Sprite.h"

Sprite::~Sprite()
{
	Renderer::GetInstance()->RemoveRenderTarget(this);
}

void Sprite::SetTexture(wstring path)
{
	texture = TextureManager::GetInstance()->LoadTexture(path);
	Renderer::GetInstance()->AddRenderTarget(this);
}

RECT Sprite::GetRect()
{
	RECT r;
	r.left = position.x - (texture->info.Width / 2 * scale.x);
	r.right = position.x + (texture->info.Width / 2 * scale.x);
	r.top = position.x - (texture->info.Width / 2 * scale.y);
	r.bottom = position.x + (texture->info.Width / 2 * scale.y);
	return r;
}

float Sprite::GetDistance(Vec2 obj)
{
	Vec2 temp = position - obj;
	return sqrt(temp.x * temp.x + temp.y * temp.y);
}

float Sprite::Look(Vec2 obj)
{
	Vec2 temp = position - obj;
	return atan2(temp.y, temp.x);
}

void Sprite::Draw()
{
	if (isactive == false)
		return;
	if (texture == nullptr)
		return;
	isui ? Director::GetInstance()->sprite->Begin(D3DXSPRITE_ALPHABLEND) :
		Director::GetInstance()->sprite->Begin(D3DXSPRITE_ALPHABLEND | D3DXSPRITE_OBJECTSPACE);
	Director::GetInstance()->sprite->SetTransform(&GetMatrix());
	Vec3 center = { texture->info.Width * pivot.x, texture->info.Height * pivot.y, 0 };
	Director::GetInstance()->sprite->Draw(texture->texture, nullptr, &center, nullptr, color);
	Director::GetInstance()->sprite->End();
}