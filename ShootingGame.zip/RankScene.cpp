#include "DXUT.h"
#include "Font.h"
#include "rankScene.h"

void rankScene::Init()
{
	name[0] = ' ';
	name[1] = ' ';
	name[2] = ' ';
	name[3] = '\0';

	for (int i = 0; i < 5; ++i)
	{
		fonts[i] = new Font();
		fonts[i]->Createfont(2, 1, L"Arial");
		fonts[i]->SetFont("");
		fonts[i]->position = { ScreenW / 2 + 300, 100 + ((float)i * 100) };
	}
	nameFont = new Font();
	nameFont->Createfont(2, 1, L"Arial");
	nameFont->SetFont("");
	nameFont->position = { 100,100 };

	scoreFont = new Font();
	scoreFont->Createfont(2, 1, L"Arial");
	scoreFont->SetFont("");
	scoreFont->position = { 100,200 };

	returnFont = new Font();
	returnFont->Createfont(2, 1, L"Arial");
	returnFont->SetFont("Press P to return");
	returnFont->position = { ScreenW / 2 - 200,600 };

	if (Director::GetInstance()->isgameend == false)
		isentered == true;
	cout << "��ũ ��" << endl;
}

void rankScene::Update()
{
	if (isentered == false && Director::GetInstance()->isgameend == true)
	{
		for (int i = 0; i < 26; ++i)
		{
			if (DXUTWasKeyPressed('A' + i))
			{
				for (int j = 0; j < sizeof(name); ++j)
				{
					if (name[j] == ' ')
					{
						name[j] = 'A' + i;
						break;
					}
				}
			}
		}

		char a[100] = { 0, };
		sprintf(a, "PLEASE ENTER YOUR INITIAL : %s", name);
		nameFont->SetFont(a);
		sprintf(a, " SCORE : %d", Director::GetInstance()->score);
		scoreFont->SetFont(a);

		if (DXUTWasKeyPressed(VK_RETURN))
		{
			if (name[0] != ' ' && name[1] != ' ' && name[2] != ' ')
			{
				Rank r;
				r.name[0] = name[0];
				r.name[1] = name[1];
				r.name[2] = name[2];
				r.name[3] = '\0';

				r.score = Director::GetInstance()->score;
				Director::GetInstance()->ranking.emplace_back(r);
				sort(Director::GetInstance()->ranking.begin(),
					Director::GetInstance()->ranking.end(),
					Director::GetInstance()->Comp);

				name[0] = ' ';
				name[1] = ' ';
				name[2] = ' ';
				name[3] = '\0';
				isentered = true;
				Director::GetInstance()->isgameend = false;
				nameFont->SetFont("");
				scoreFont->SetFont("");
			}
		}
	}

	if (DXUTWasKeyPressed(VK_BACK))
	{
		name[0] = ' ';
		name[1] = ' ';
		name[2] = ' ';
		name[3] = '\0';
	}

	for (int i = 0; i < Director::GetInstance()->ranking.size(); ++i)
	{
		if (i < 5)
		{
			char buff[100] = { 0, };
			sprintf(buff, "%d  %s  %d", i + 1,
				Director::GetInstance()->ranking[i].name,
				Director::GetInstance()->ranking[i].score);
			fonts[i]->SetFont(buff);
		}
	}

	if (DXUTWasKeyPressed('P'))
	{
		cout << "P Click" << endl;
		cout << Director::GetInstance()->lookrank << endl;
		if (Director::GetInstance()->lookrank == true)
		{
			Director::GetInstance()->lookrank == false;
			Director::GetInstance()->ChangeScene(new menuScene);
		}
		if (isentered)
			Director::GetInstance()->ChangeScene(new menuScene);
	}
}

void rankScene::Exit()
{
	for (int i = 0; i < 5; ++i)
		delete fonts[i];
	delete nameFont;
	delete scoreFont;
	delete returnFont;
}