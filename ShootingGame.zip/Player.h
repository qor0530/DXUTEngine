#pragma once
#include "Bullet.h"
#include "Base.h"
#include "Sound.h"
class Player :
	public Base
{
public:
	Player();
	virtual ~Player();
	int level = 1;
	int exp = 0;
	int maxexp = 10;
	int maxhp = 5;
	float fireBetTime;
	float straightTime;
	float radialTime;
	float ShieldTime;
	float ScoolTime;
	bool levelUp = false;
	bool isinvincible = false;
	bool isStraight;
	void ShootBullet();
	void Toggle();
	void Move() override;
	void Clip();
	void Leveling();
	void Update() override;
	void Shield();
};