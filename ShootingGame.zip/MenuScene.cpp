#include "DXUT.h"
#include "Director.h"
#include "gameScene.h"
#include "menuScene.h"

void menuScene::Init()
{
	for (int i = 0; i < 3; ++i)
	{
		buttons[i] = new Sprite();
		buttons[i]->position = { ScreenW / 2 + 400,ScreenH / 2 + ((float)i * 100) };
		buttons[i]->isui = true;
		buttons[i]->scale = { 0.7f,0.7f };
	}
	buttons[0]->SetTexture(L"start.png");
	buttons[1]->SetTexture(L"rank.png");
	buttons[2]->SetTexture(L"exit.png");

	font = new Font();
	font->Createfont(6, 2, L"Arial");
	font->SetFont("SHOOTING GAME");
	font->position = { 180,150 };
}

void menuScene::Update()
{
	POINT p;
	GetCursorPos(&p);
	ScreenToClient(DXUTGetHWND(), &p);

	if (Director::GetInstance()->OnMouseDown())
	{
		for (int i = 0; i < 3; ++i)
		{
			if (PtInRect(&buttons[i]->GetRect(), p))
			{
				switch (i)
				{
				case 0:
					cout << "START" << endl;
					Director::GetInstance()->ChangeScene(new gameScene);
					return;
					break;
				case 1:
					cout << "RANK" << endl;
					Director::GetInstance()->lookrank = true;
					Director::GetInstance()->ChangeScene(new rankScene);
					return;
					break;
				case 2:
					cout << "EXIT" << endl;
					exit(1);
					break;
				}
			}
		}
	}

	if (DXUTWasKeyPressed('P'))
		Director::GetInstance()->ChangeScene(new gameScene);
}

void menuScene::Exit()
{
	for (int i = 0; i < 3; ++i)
		delete buttons[i];
	delete font;
}