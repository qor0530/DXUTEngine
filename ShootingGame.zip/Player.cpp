#include "DXUT.h"
#include "Player.h"

Player::Player()
{
	HP = 5;
	movespeed = 200.f;
	position = { ScreenW / 2,ScreenH / 2 + 150 };
	scale = { 0.7f,0.7f };
	layer = 31;
	objecttexture->SetTexture(L"player1.png");
	color.a = 0;
	SetTexture(L"collisionbox.png");
	isPlayer = true;

	type = PLAYER;
}

Player::~Player()
{
}

void Player::ShootBullet()
{
	if (DXUTWasKeyPressed(VK_SPACE))
	{
		BulletManager::GetInstance()->ShootBullet(position, PLAYER);
	}
}

void Player::Move()
{
	if (DXUTIsKeyDown('W'))
		position.y -= movespeed * DELTATIME;
	if (DXUTIsKeyDown('A'))
		position.x -= movespeed * DELTATIME;
	if (DXUTIsKeyDown('S'))
		position.y += movespeed * DELTATIME;
	if (DXUTIsKeyDown('D'))
		position.x += movespeed * DELTATIME;
}

void Player::Clip()
{
	if (position.x > ScreenW - texture->info.Width / 2 * scale.x)
		position.x = ScreenW - texture->info.Width / 2 * scale.x;
	if (position.x < texture->info.Width / 2 * scale.x)
		position.x = texture->info.Width / 2 * scale.x;
	if (position.y > ScreenH - texture->info.Height / 2 * scale.y)
		position.y = ScreenH - texture->info.Height / 2 * scale.y;
	if (position.y < texture->info.Height / 2 * scale.y)
		position.y = texture->info.Height / 2 * scale.y;
}

void Player::Update()
{
	if (DXUTWasKeyPressed(VK_F2))
		isinvincible = !isinvincible;

	if (isinvincible)
		HP = 5;

	ShootBullet();
	Base::Update();
	Clip();
}