#include "DXUT.h"
#include "menuScene.h"
#include "gameScene.h"

void gameScene::Init()
{
	cout << "����" << endl;
	p = new Player();
	BulletManager::GetInstance()->CreateBullet();
	EnemyManager::GetInstance()->CreateEnemy();
	EffectManager::GetInstance()->CreateEffect();

	Camera::GetInstance()->CameraInit();
	Sound::GetInstance()->LoadSound(L"Res/Bgm.wav", L"BGM");
	Sound::GetInstance()->PlaySFX(L"BGM", true);

	for (int i = 0; i < 2; ++i)
	{
		back[i] = new Sprite();
		back[i]->SetTexture(L"background.png");
		back[i]->layer = -30;
		Renderer::GetInstance()->Sort();
	}
	back[0]->position = { ScreenW / 2, ScreenH / 2 };
	back[1]->position = { ScreenW / 2, -(ScreenH / 2) };

	for (int i = 0; i < 5; ++i)
	{
		ui[i] = new Sprite();
		ui[i]->scale = { 2,2 };
		ui[i]->layer = 10;
		ui[i]->SetTexture(L"player1.png");

		ui[i]->position = { 55 + ((float)i * 60), 45 };
	}

	b = new Boss();
	b->position = { ScreenW / 2, -100 };

	scorefont = new Font();
	scorefont->Createfont(2, 2, L"Arial");
	scorefont->position = { ScreenW / 2 + 400,10 };
}

void gameScene::Update()
{
	for (int i = 0; i < 5; ++i)
		ui[i]->isactive = false;
	for (int i = 0; i < p->HP; ++i)
		ui[i]->isactive = true;

	bossspawntime += DELTATIME;
	if (bossspawntime > 3)
	{
		if (b->position.y < 100)
			b->position.y += 30 * DELTATIME;
		else
			b->startpattern = true;
	}

	dt += DELTATIME;
	if (dt > 3.f)
	{
		if (num == 0)
		{
			EnemyManager::GetInstance()->SpawnEnemy({ ScreenW / 2,0 }, E1, p);
			num = 1;
		}
		else
		{
			EnemyManager::GetInstance()->SpawnEnemy({ ScreenW / 2,0 }, E2, p);
			num = 0;
		}
		dt = 0;
	}

	Camera::GetInstance()->CameraUpdate();

	for (int i = 0; i < 2; ++i)
	{
		back[i]->position.y += 200.f * DELTATIME;

		if (back[i]->position.y > (ScreenH + ScreenH / 2))
			back[i]->position.y = -(ScreenH / 2);
	}

	string num = to_string(Director::GetInstance()->score);
	string result = "Score : " + num;
	scorefont->SetFont((char*)result.c_str());

	if (DXUTWasKeyPressed('U'))
		Director::GetInstance()->score += 100;

	if (DXUTWasKeyPressed('P'))
	{
		Director::GetInstance()->ChangeScene(new menuScene);
		return;
	}

	if (DXUTWasKeyPressed(VK_F1))
	{
		Director::GetInstance()->score += 100;
	}

	if (p->HP <= 0)
	{
		Director::GetInstance()->isgameend = true;
		Director::GetInstance()->ChangeScene(new rankScene);
		return;
	}
}

void gameScene::Exit()
{
	cout << "������" << endl;
	for (int i = 0; i < 5; ++i)
		delete	ui[i];
	for (int i = 0; i < 2; ++i)
		delete	back[i];
	delete p;
	delete b;
	delete scorefont;

	BulletManager::GetInstance()->DeleteBullet();
	EnemyManager::GetInstance()->DeleteEnemy();
	EffectManager::GetInstance()->DeleteEffect();
	Sound::GetInstance()->StopSFX(L"BGM");
}