#pragma once
#include "Singleton.h"
#include "Base.h"
class Bullet :
	public Base
{
public:
	Bullet();
	Vec2 dir;
	bool isdir = false;
	void Move() override;
	void Clip();
	void Update() override;
};

class BulletManager :
	public Singleton<BulletManager>
{
public:
	vector<Bullet*> bullets;
	void CreateBullet();
	void ShootBullet(Vec2 pos, ObjectType type, Vec2 dir = { 0,0 });
	void DeleteBullet();
};
