#include "DXUT.h"
#include "Texture.h"

Texture* TextureManager::LoadTexture(wstring path)
{
	for (auto it : texturelist)
		if (it->tag == path)
			return it;
	Texture* tex = new Texture;
	auto route = L"Res/" + path;
	tex->tag = path;

	if (FAILED(D3DXCreateTextureFromFileEx(DXUTGetD3D9Device(),
		route.c_str(),
		-2, -2, 1, 0,
		D3DFORMAT::D3DFMT_A8B8G8R8,
		D3DPOOL::D3DPOOL_MANAGED,
		D3DX_FILTER_NONE,
		D3DX_FILTER_NONE, 0,
		&tex->info, nullptr, &tex->texture)))
	{
		wcout << "Failed : " << route << endl;
		delete tex;
	}
	else
	{
		wcout << "Complete : " << route << endl;
		texturelist.emplace_back(tex);
		return tex;
	}
}