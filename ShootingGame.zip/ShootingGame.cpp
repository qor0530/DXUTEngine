#include "DXUT.h"
#include "resource.h"
#include "Director.h"
#include "menuScene.h"

HRESULT CALLBACK OnD3D9CreateDevice(IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc,
	void* pUserContext)
{
	srand(time(0));
	Director::GetInstance()->Init();
	return S_OK;
}

HRESULT CALLBACK OnD3D9ResetDevice(IDirect3DDevice9* pd3dDevice, const D3DSURFACE_DESC* pBackBufferSurfaceDesc,
	void* pUserContext)
{
	return S_OK;
}

void CALLBACK OnFrameMove(double fTime, float fElapsedTime, void* pUserContext)
{
}

void CALLBACK OnMouse(bool bLeftButtonDown, bool bRightButtonDown, bool bMiddleButtonDown, bool bSideButton1Down, bool bSideButton2Down, int nMouseWheelDelta, int xPos, int yPos, void* pUserContext)
{
	if (bLeftButtonDown)
		Director::GetInstance()->mouse = 1;
	else if (!bLeftButtonDown)
		Director::GetInstance()->mouse = 3;
}

void CALLBACK OnD3D9FrameRender(IDirect3DDevice9* pd3dDevice, double fTime, float fElapsedTime, void* pUserContext)
{
	HRESULT hr;

	V(pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_ARGB(0, 0, 0, 0), 1.0f, 0));

	if (SUCCEEDED(pd3dDevice->BeginScene()))
	{
		Director::GetInstance()->UpdateScene();
		V(pd3dDevice->EndScene());
	}
}

void CALLBACK OnD3D9LostDevice(void* pUserContext)
{
}

void CALLBACK OnD3D9DestroyDevice(void* pUserContext)
{
	exit(1);
}

int main()
{
#if defined(DEBUG) | defined(_DEBUG)
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
#endif

	DXUTSetCallbackD3D9DeviceCreated(OnD3D9CreateDevice);
	DXUTSetCallbackD3D9DeviceReset(OnD3D9ResetDevice);
	DXUTSetCallbackD3D9FrameRender(OnD3D9FrameRender);
	DXUTSetCallbackD3D9DeviceLost(OnD3D9LostDevice);
	DXUTSetCallbackD3D9DeviceDestroyed(OnD3D9DestroyDevice);
	DXUTSetCallbackFrameMove(OnFrameMove);
	DXUTSetCallbackMouse(OnMouse);

	DXUTInit(true, true);
	DXUTSetHotkeyHandling(true, true, true);
	DXUTSetCursorSettings(true, true);
	DXUTCreateWindow(L"test1");
	DXUTCreateDevice(true, ScreenW, ScreenH);

	Director::GetInstance()->ChangeScene(new menuScene);

	DXUTMainLoop();

	return DXUTGetExitCode();
}