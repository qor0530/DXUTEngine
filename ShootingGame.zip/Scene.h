#pragma once
class Scene
{
public:
	virtual void Init() PURE;
	virtual void Update() PURE;
	virtual void Exit() PURE;
};
