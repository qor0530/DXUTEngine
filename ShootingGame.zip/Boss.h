#pragma once
#include "EnemyManager.h"
#include "Enemy.h"
class Boss :
	public Enemy
{
public:
	Boss();
	virtual ~Boss();

	Sprite* hpbar = nullptr;

	int state = 0;
	int level = 1;
	bool startpattern = false;
	bool spawnmonster = false;
	float movementtime = 0;
	void ShootBullet();
	void SpawnMonster();
	void LevelUp();
	void Reset();
	void Activefalse() override;
	void Move() override;
	void Update() override;
};
