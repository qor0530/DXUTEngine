#include "DXUT.h"
#include "Enemy.h"

Enemy::Enemy()
{
	HP = 3;
	movespeed = 10;
	scale = { 1,1 };
	position = { 9999,9999 };
	attackspeed = 1.1f;
	color.a = 0;
	layer = 2;
	SetTexture(L"collisionbox.png");

	objecttexture->layer = 3;
	Renderer::GetInstance()->Sort();
	objecttexture->scale = { 2,2 };

	type = ENEMY;
}

void Enemy::Enemy1Move()
{
	position.y += movespeed * DELTATIME;
}

void Enemy::Enemy1Attack()
{
	if (deltatime > attackspeed)
	{
		BulletManager::GetInstance()->ShootBullet(position, ENEMY);
		deltatime = 0;
	}
	else
		deltatime += DELTATIME;

	objecttexture->Animation(L"m1", 0.2f, 5);
}

void Enemy::Enemy2Move()
{
	direction = *playerpos - position;
	D3DXVec2Normalize(&direction, &direction);
	position += movespeed * DELTATIME * direction;
}

void Enemy::Enemy2Attack()
{
	if (deltatime > attackspeed)
	{
		BulletManager::GetInstance()->ShootBullet(position, ENEMY);
		deltatime = 0;
	}
	else
		deltatime += DELTATIME;

	objecttexture->Animation(L"m2", 0.2f, 5);
}

void Enemy::Move()
{
	switch (etype)
	{
	case E1:
		Enemy1Move();
		break;
	case E2:
		Enemy2Move();
		break;
	}
}

void Enemy::Update()
{
	switch (etype)
	{
	case E1:
		Enemy1Attack();
		break;
	case E2:
		Enemy2Attack();
		break;
	}
	Base::Update();
}